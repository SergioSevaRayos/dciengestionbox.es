<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // 1. Creamos 20 alumnos de prueba usando la Factory de Laravel
        // Les asignamos el rol 'student' y 10 créditos (bonos)
        User::factory()->count(20)->create([
            'role' => 'student',
            'credits' => 0,
        ]);

        // 2. Creamos o actualizamos tu usuario Admin para que no lo pierdas
        User::updateOrCreate(
            ['email' => 'admin@admin.com'], // Si ya existe este email, solo lo actualiza
            [
                'name' => 'Admin Sergio',
                'password' => Hash::make('password'), // La contraseña será 'password'
                'role' => 'admin',
                'credits' => 0,
            ]
        );
    }
}
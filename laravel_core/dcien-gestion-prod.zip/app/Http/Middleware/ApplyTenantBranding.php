<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Filament\Facades\Filament;
use Filament\Support\Facades\FilamentColor;
use Filament\Support\Colors\Color;
use App\Models\GymSetting;

class ApplyTenantBranding
{
    public function handle(Request $request, Closure $next)
    {
        $tenant = Filament::getTenant();

        if ($tenant) {
            // Buscamos la configuración de este gimnasio en concreto
            $settings = GymSetting::where('gym_id', $tenant->id)->first();

            if ($settings) {
                // 1. Inyectamos el Color Primario
                if (!empty($settings->primary_color)) {
                    FilamentColor::register([
                        'primary' => Color::hex($settings->primary_color),
                    ]);
                }

                // 2. Inyectamos el Nombre del Gimnasio
                if (!empty($settings->gym_name)) {
                    Filament::getCurrentPanel()->brandName($settings->gym_name);
                }

                // 3. Inyectamos el Logo
                if (!empty($settings->logo)) {
                    Filament::getCurrentPanel()->brandLogo(asset('storage/' . $settings->logo));
                    Filament::getCurrentPanel()->brandLogoHeight('3rem');
                }

                // 4. Inyectamos el Favicon
                if (!empty($settings->favicon)) {
                    Filament::getCurrentPanel()->favicon(asset('storage/' . $settings->favicon));
                }
            }
        }

        return $next($request);
    }
}

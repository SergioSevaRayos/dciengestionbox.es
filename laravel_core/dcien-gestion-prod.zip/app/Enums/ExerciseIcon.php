<?php

namespace App\Enums;

use Filament\Support\Contracts\HasIcon;

enum ExerciseIcon: string implements HasIcon
{
    // Asociamos cada nombre exacto de ejercicio con un icono de Heroicons
    case PushPress = 'Push Press';
    case BackSquat = 'Back Squat';
    case FrontSquat = 'Front Squat';
    case Deadlift = 'Deadlift';
    case BenchPress = 'Bench Press';
    case Snatch = 'Snatch';
    case CleanJerk = 'Clean & Jerk';

    // Función que devuelve el icono correspondiente
    public function getIcon(): ?string
    {
        return match ($this) {
            self::PushPress => 'heroicon-m-arrow-up-tray',    // Barra hacia arriba
            self::BackSquat => 'heroicon-m-arrows-up-down',   // Movimiento arriba-abajo
            self::FrontSquat => 'heroicon-m-user',            // Figura humana
            self::Deadlift => 'heroicon-m-minus-small',       // Barra en el suelo
            self::BenchPress => 'heroicon-m-archive-box',      // Caja/Banco
            self::Snatch => 'heroicon-m-bolt',                // Rayo/Velocidad
            self::CleanJerk => 'heroicon-m-sparkles',         // Chispas/Poder
        };
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Package extends Model
{
    use \App\Traits\BelongsToGym;

    // Permisos para guardar los datos de las tarifas
    protected $fillable = [
        'gym_id',
        'name',
        'credits',
        'price',
        'validity_days',
    ];

    
}
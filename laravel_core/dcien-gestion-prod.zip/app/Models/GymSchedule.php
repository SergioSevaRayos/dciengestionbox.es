<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class GymSchedule extends Model
{
    use \App\Traits\BelongsToGym;

    protected $fillable = [
        'gym_id','class_type_id', 'start_time', 'end_time', 'days_of_week', 'repeat_until', 'capacity'];

    protected $casts = [
        'days_of_week' => 'array',
        'repeat_until' => 'date',
    ];

    // --- ESTE ES EL SEGURO DE BORRADO ---
    protected static function booted()
    {
        static::deleting(function ($schedule) {
            // Borramos directamente por ID para no dejar huérfanos
            \App\Models\GymSession::where('gym_schedule_id', $schedule->id)->delete();
        });
    }

    public function classType(): BelongsTo
    {
        return $this->belongsTo(ClassType::class);
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(GymSession::class);
    }

    
}
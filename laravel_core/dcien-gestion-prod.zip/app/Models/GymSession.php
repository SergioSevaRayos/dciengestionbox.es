<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GymSession extends Model
{
    use \App\Traits\BelongsToGym;

    // AÑADIMOS 'gym_schedule_id' AQUÍ:
    protected $fillable = [
        'gym_id',
        'class_type_id',
        'start_time',
        'end_time',
        'capacity',
        'gym_schedule_id'
    ];

    protected $casts = [
        'start_time' => 'datetime',
        'end_time' => 'datetime',
    ];

    public function classType(): BelongsTo
    {
        return $this->belongsTo(ClassType::class);
    }

    // Relación inversa para que Laravel entienda el vínculo
    public function schedule(): BelongsTo
    {
        return $this->belongsTo(GymSchedule::class, 'gym_schedule_id');
    }
    public function bookings()
    {
        return $this->hasMany(Booking::class);
    }

    
}
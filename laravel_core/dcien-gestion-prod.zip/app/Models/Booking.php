<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Booking extends Model
{
    use \App\Traits\BelongsToGym;

    protected $fillable = [
        'gym_id','user_id', 'gym_session_id', 'status', 'notified_at'];

    protected function casts(): array
    {
        return [
            'notified_at' => 'datetime',
        ];
    }

    public function user() { return $this->belongsTo(User::class); }
    public function gymSession() { return $this->belongsTo(GymSession::class); }

    
}
<?php

namespace App\Models;

use App\Enums\ExerciseIcon;
use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    use \App\Traits\BelongsToGym;

    // Añadimos 'category' a la lista blanca
    protected $fillable = [
        'gym_id','name', 'category'];

    protected $casts = [
        'name' => ExerciseIcon::class,
    ];

    public function personalRecords()
    {
        return $this->hasMany(PersonalRecord::class);
    }

    
}
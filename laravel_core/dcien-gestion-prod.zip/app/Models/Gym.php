<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Gym extends Model
{
    protected $fillable = ['name', 'slug', 'stripe_id', 'is_subscribed'];

    protected $casts = [
        'is_subscribed' => 'boolean',
    ];

    // Relación con los Gestores/Usuarios
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class);
    }

    // --- RELACIONES SAAS (Para que Filament pueda guardar datos aislados) ---

    public function classTypes(): HasMany
    {
        return $this->hasMany(ClassType::class);
    }

    public function exercises(): HasMany
    {
        return $this->hasMany(Exercise::class);
    }

    public function gymSessions(): HasMany
    {
        return $this->hasMany(GymSession::class);
    }

    public function gymSchedules(): HasMany
    {
        return $this->hasMany(GymSchedule::class);
    }

    public function packages(): HasMany
    {
        return $this->hasMany(Package::class);
    }

    public function userPackages(): HasMany
    {
        return $this->hasMany(UserPackage::class);
    }

    public function packageRenewals(): HasMany
    {
        return $this->hasMany(PackageRenewal::class);
    }

    public function personalRecords(): HasMany
    {
        return $this->hasMany(PersonalRecord::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }
}

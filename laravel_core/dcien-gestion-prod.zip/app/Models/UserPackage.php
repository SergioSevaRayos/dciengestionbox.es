<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserPackage extends Model
{
    use \App\Traits\BelongsToGym;

    protected $fillable = [
        'gym_id',
        'user_id',
        'package_id',
        'is_paid',       // AQUÍ ESTÁ EL CAMPO QUE CAUSABA EL ERROR DE GUARDADO
        'total_classes',
        'remaining_classes',
        'expires_at',
        'is_active',
    ];

    protected $casts = [
        'is_paid' => 'boolean',
        'is_active' => 'boolean',
        'expires_at' => 'datetime',
    ];

    // RELACIÓN 1: Un bono comprado pertenece a un Alumno (Usuario)
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // RELACIÓN 2: Un bono comprado pertenece a un tipo de Paquete (Bono de 10, Mensualidad, etc.)
    public function package(): BelongsTo
    {
        return $this->belongsTo(Package::class);
    }

    
}
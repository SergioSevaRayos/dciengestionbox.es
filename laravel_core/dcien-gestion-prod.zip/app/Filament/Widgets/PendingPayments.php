<?php

namespace App\Filament\Widgets;

use App\Models\UserPackage;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use Filament\Notifications\Notification;

class PendingPayments extends BaseWidget
{
    protected static ?string $heading = '🚨 Pendientes de Pago (Morosos)';
    protected static ?int $sort = 1;
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            // Filtramos SOLO los bonos que tienen is_paid en false
            ->query(
                UserPackage::query()->where('is_paid', false)->latest()
            )
            ->columns([
                Tables\Columns\TextColumn::make('user.name')
                    ->label('Alumno')
                    ->searchable()
                    ->weight('bold'),
                    
                Tables\Columns\TextColumn::make('package.name')
                    ->label('Bono Activado')
                    ->badge()
                    ->color('warning'),
                    
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Fecha de Activación')
                    ->dateTime('d/m/Y H:i')
                    ->description(fn ($record) => $record->created_at->diffForHumans()),
            ])
            ->actions([
                Tables\Actions\Action::make('pay')
                    ->label('Confirmar Pago')
                    ->icon('heroicon-m-currency-euro')
                    ->color('success')
                    ->requiresConfirmation()
                    ->modalHeading('¿Confirmar pago?')
                    ->modalDescription('¿Estás seguro de que este alumno ya te ha pagado el bono? Desaparecerá de esta lista.')
                    ->modalSubmitActionLabel('Sí, ya ha pagado')
                    ->action(function (UserPackage $record) {
                        // Marcamos como pagado
                        $record->update(['is_paid' => true]);
                        
                        Notification::make()
                            ->title('Pago confirmado')
                            ->body('El bono de ' . $record->user->name . ' ha sido marcado como pagado.')
                            ->success()
                            ->send();
                    }),
            ])
            ->emptyStateHeading('¡Todo al día!')
            ->emptyStateDescription('Ningún alumno te debe dinero ahora mismo.')
            ->emptyStateIcon('heroicon-o-face-smile');
    }
}

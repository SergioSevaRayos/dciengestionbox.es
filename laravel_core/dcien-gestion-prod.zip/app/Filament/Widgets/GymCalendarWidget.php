<?php

namespace App\Filament\Widgets;

use App\Models\GymSession;
use App\Filament\Resources\GymSessionResource;
use Saade\FilamentFullCalendar\Widgets\FullCalendarWidget;

class GymCalendarWidget extends FullCalendarWidget
{
  protected int | string | array $columnSpan = 'full';

  public function fetchEvents(array $fetchInfo): array
  {
    return GymSession::with('classType')
      ->whereBetween('start_time', [$fetchInfo['start'], $fetchInfo['end']])
      ->get()
      ->map(function (GymSession $session) {
        $startTime = \Carbon\Carbon::parse($session->start_time)->format('H:i');

        return [
          'id' => $session->id,
          'title' => $startTime . ' ' . $session->classType->name,
          'start' => $session->start_time->toIso8601String(), // Formato ISO estricto
          'end' => $session->end_time->toIso8601String(),
          'backgroundColor' => $session->classType->color ?? '#3b82f6',
          'borderColor' => 'transparent',
          'allDay' => false, // ESTO ES VITAL para que no cruce días
          // Añadimos esta propiedad para forzar que sea un bloque individual
          'display' => 'block',
          'url' => GymSessionResource::getUrl('edit', ['record' => $session]),
        ];
      })
      ->toArray();
  }

  // --- CONFIGURACIÓN VISUAL DEL CALENDARIO ---
  public function config(): array
  {
    return [
      'initialView' => 'timeGridWeek', // O 'timeGridWeek' 'dayGridMonth' si prefieres semana
      'locale' => 'es',
      'firstDay' => 1,
      'headerToolbar' => [
        'left' => 'prev,next today',
        'center' => 'title',
        'right' => 'dayGridMonth,timeGridWeek',
      ],
      // --- ESTO ARREGLA LA VISUALIZACIÓN ---
      'eventDisplay' => 'block',      // Fuerza a que cada evento sea una "píldora" independiente
      'dayMaxEvents' => 3,            // Si hay más de 3 clases, pone un "+ ver más" (evita que el calendario crezca infinito)
      'eventTimeFormat' => [          // Fuerza el formato de 24h en el calendario
        'hour' => '2-digit',
        'minute' => '2-digit',
        'meridiem' => false,
        'hour12' => false
      ],
      // -------------------------------------
      'slotMinTime' => '07:00:00',
      'slotMaxTime' => '22:00:00',
      'allDaySlot' => false,
      'height' => 'auto',
    ];
  }
}

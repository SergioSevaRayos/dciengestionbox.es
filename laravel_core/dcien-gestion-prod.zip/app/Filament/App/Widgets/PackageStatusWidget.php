<?php

namespace App\Filament\App\Widgets;

use Filament\Widgets\Widget;
use Filament\Actions\Action;
use Filament\Actions\Concerns\InteractsWithActions;
use Filament\Actions\Contracts\HasActions;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Components\Select;
use App\Models\PackageRenewal;
use App\Models\Package;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Livewire\Attributes\On;

class PackageStatusWidget extends Widget implements HasActions, HasForms
{
    use InteractsWithActions;
    use InteractsWithForms;

    protected static string $view = 'filament.app.widgets.package-status-widget';
    protected int | string | array $columnSpan = 'full';

    public int $daysLeft = 999;
    public bool $hasPending = false;
    public int $creditsLeft = 0;
    public string $currentPackageName = 'Ninguno';

    public function mount()
    {
        $this->loadData();
    }

    #[On('credits-updated')]
    public function loadData()
    {
        $user = auth()->user()->fresh();
        $this->creditsLeft = $user->credits ?? 0;

        $latestUserPackage = DB::table('user_packages')
            ->where('user_id', $user->id)
            ->orderBy('id', 'desc')
            ->first();

        if ($latestUserPackage) {
            $package = Package::find($latestUserPackage->package_id);
            if ($package) {
                $this->currentPackageName = $package->name;
                $expirationDate = $latestUserPackage->expires_at 
                    ? Carbon::parse($latestUserPackage->expires_at) 
                    : Carbon::parse($latestUserPackage->created_at)->addDays($package->validity_days ?? 30);

                $this->daysLeft = (int) now()->diffInDays($expirationDate, false);
                if ($this->daysLeft === 0 && now()->lessThan($expirationDate)) {
                    $this->daysLeft = 1;
                }
            }
        } else {
            $this->currentPackageName = 'Ninguno';
            $this->daysLeft = 0;
        }

        $this->hasPending = PackageRenewal::where('user_id', $user->id)
            ->where('status', 'pendiente')
            ->exists();
    }

    public function renewAction(): Action
    {
        return Action::make('renew')
            ->label('Solicitar Renovación')
            ->color('warning')
            ->icon('heroicon-m-bolt')
            ->form([
                Select::make('package_id')
                    ->label('¿Qué bono quieres renovar/contratar?')
                    ->options(Package::pluck('name', 'id'))
                    ->required(),
            ])
            ->action(function (array $data) {
                PackageRenewal::create([
                    'user_id' => auth()->id(),
                    'package_id' => $data['package_id'],
                    'status' => 'pendiente',
                ]);
                
                // NOTIFICACIÓN ASÍNCRONA A LOS ADMINISTRADORES
                $admins = \App\Models\User::where('role', 'admin')->get();
                Notification::make()
                    ->title('💳 Nueva Solicitud de Bono')
                    ->body(auth()->user()->name . ' ha solicitado un bono y está pendiente de validación.')
                    ->warning()
                    ->sendToDatabase($admins);

                $this->loadData(); 
                Notification::make()->title('Solicitud enviada al gestor')->success()->send();
            });
    }
}

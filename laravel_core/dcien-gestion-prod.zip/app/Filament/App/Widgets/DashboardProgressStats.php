<?php

namespace App\Filament\App\Widgets;

use App\Models\PersonalRecord;
use App\Models\Exercise;
use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use Illuminate\Support\Facades\Auth;

class DashboardProgressStats extends BaseWidget
{
    protected static ?int $sort = 1;
    
    protected function getStats(): array
    {
        $user = Auth::user();
        $exercises = Exercise::all();
        $stats = [];
        
        foreach ($exercises as $exercise) {
            $records = PersonalRecord::where('user_id', $user->id)
                ->where('exercise_id', $exercise->id)
                ->orderBy('achieved_at', 'asc')
                ->get();
                
            if ($records->isNotEmpty()) {
                $bestWeight = $records->max('weight');
                $nameStr = $exercise->name instanceof \UnitEnum ? $exercise->name->value : $exercise->name;
                
                $chartData = $records->pluck('weight')->map(fn($w) => (float) $w)->toArray();

                $firstWeight = $chartData[0] ?? 0;
                $lastWeight = end($chartData) ?: 0;
                $isImproving = $lastWeight >= $firstWeight;
                
                $color = $isImproving ? 'success' : 'danger';
                $icon = $isImproving ? 'heroicon-m-arrow-trending-up' : 'heroicon-m-arrow-trending-down';

                $stats[] = Stat::make((string) $nameStr, $bestWeight . ' Kg')
                    ->description('Curva de progreso')
                    ->descriptionIcon($icon)
                    ->color($color)
                    ->chart($chartData)
                    ->extraAttributes([
                        'class' => 'cursor-pointer hover:ring-2 hover:ring-' . $color . '-500 transition-all duration-200',
                        // CORRECCIÓN AQUÍ: x-on:click usando Javascript para redirigir
                        'x-on:click' => "window.location.href = '/app/mis-marcas'",
                    ]);
            }
        }
        
        return $stats;
    }
}

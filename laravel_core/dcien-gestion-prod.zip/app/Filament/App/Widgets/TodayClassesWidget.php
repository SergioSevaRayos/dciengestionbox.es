<?php

namespace App\Filament\App\Widgets;

use Filament\Tables;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget as BaseWidget;
use App\Models\GymSession;
use App\Models\Booking;
use Filament\Notifications\Notification;
use Filament\Notifications\Actions\Action as NotifyAction;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Filament\Tables\Columns\Layout\Stack;
use Filament\Tables\Columns\Layout\Split;

class TodayClassesWidget extends BaseWidget
{
    protected static ?string $heading = 'Próximas Clases (24h)';
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->poll('3s')
            ->paginated(false)
            ->query(
                GymSession::query()
                    ->whereBetween('start_time', [now(), now()->addHours(24)])
                    ->orderBy('start_time', 'asc')
            )
            ->contentGrid(['md' => 2, 'xl' => 3])
            ->columns([
                Stack::make([
                    Tables\Columns\TextColumn::make('classType.name')->weight('bold')->size(Tables\Columns\TextColumn\TextColumnSize::Large),
                    Split::make([
                        Tables\Columns\TextColumn::make('start_time')
                            ->icon('heroicon-m-clock')
                            ->formatStateUsing(fn ($state) => Carbon::parse($state)->format('d/m H:i'))
                            ->badge()->color('info')->grow(false),
                        
                        Tables\Columns\TextColumn::make('plazas')
                            ->state(function (GymSession $record) {
                                $ocupadas = $record->bookings()->where('status', 'booked')->count();
                                $espera = $record->bookings()->where('status', 'waiting')->count();
                                $libres = max(0, $record->capacity - $ocupadas);
                                
                                if ($libres > 0) {
                                    return "{$libres} de {$record->capacity} libres";
                                } elseif ($espera < 5) {
                                    return "Lleno ({$espera}/5 espera)";
                                } else {
                                    return "100% Completo";
                                }
                            })
                            ->badge()
                            ->color(fn($state) => str_contains($state, 'libres') ? 'success' : (str_contains($state, 'Completo') ? 'danger' : 'warning'))
                            ->alignEnd(),
                    ]),
                ])->space(3),
            ])
            ->actions([
                Tables\Actions\Action::make('apuntarse')
                    ->label(function (GymSession $record) {
                        // SEGURIDAD UI: Cambiamos el texto si no tiene clases
                        if (Auth::user()->credits <= 0) return 'Sin Clases';

                        $apertura = Carbon::parse($record->start_time)->subHours(12);
                        if (now()->lessThan($apertura)) {
                            return 'Abre ' . $apertura->format('H:i');
                        }

                        $ocupadas = $record->bookings()->where('status', 'booked')->count();
                        $espera = $record->bookings()->where('status', 'waiting')->count();
                        
                        if (($ocupadas + $espera) < $record->capacity) return '¡Apuntarse!';
                        if ($espera < 5) return 'Entrar en Espera';
                        return 'Aforo Completo';
                    })
                    ->button()
                    ->color(function (GymSession $record) {
                        // SEGURIDAD UI: Ponemos el botón en rojo si no tiene clases
                        if (Auth::user()->credits <= 0) return 'danger';

                        $apertura = Carbon::parse($record->start_time)->subHours(12);
                        if (now()->lessThan($apertura)) return 'gray';

                        $ocupadas = $record->bookings()->where('status', 'booked')->count();
                        $espera = $record->bookings()->where('status', 'waiting')->count();
                        
                        if (($ocupadas + $espera) < $record->capacity) return 'success';
                        if ($espera < 5) return 'warning';
                        return 'gray';
                    })
                    ->disabled(function (GymSession $record) {
                        // SEGURIDAD UI: Desactivamos el clic si no tiene clases
                        if (Auth::user()->credits <= 0) return true;

                        $apertura = Carbon::parse($record->start_time)->subHours(12);
                        if (now()->lessThan($apertura)) return true;

                        $ocupadas = $record->bookings()->where('status', 'booked')->count();
                        $espera = $record->bookings()->where('status', 'waiting')->count();
                        return $ocupadas >= $record->capacity && $espera >= 5;
                    })
                    ->visible(fn($record) => !$record->bookings()->where('user_id', Auth::id())->exists())
                    ->action(function (GymSession $record) {
                        $user = Auth::user();

                        // CORTAFUEGOS BACKEND: Por si alguien intenta forzar la reserva
                        if ($user->credits <= 0) {
                            Notification::make()->title('No te quedan clases disponibles.')->danger()->send();
                            return;
                        }

                        DB::transaction(function () use ($record, $user) {
                            $session = GymSession::lockForUpdate()->find($record->id);
                            if (!$session) return;
                            if ($session->bookings()->where('user_id', $user->id)->exists()) return;

                            $ocupadas = $session->bookings()->where('status', 'booked')->count();
                            $espera = $session->bookings()->where('status', 'waiting')->count();

                            if (($ocupadas + $espera) < $session->capacity) {
                                Booking::create(['user_id' => $user->id, 'gym_session_id' => $session->id, 'status' => 'booked']);
                                $user->decrement('credits');
                                $this->dispatch('credits-updated');
                                Notification::make()->title('¡Plaza Confirmada!')->success()->send();
                            } elseif ($espera < 5) {
                                // A la lista de espera SÍ le dejamos entrar aunque no le cobramos la clase aún
                                Booking::create(['user_id' => $user->id, 'gym_session_id' => $session->id, 'status' => 'waiting']);
                                Notification::make()->title('Clase llena. Entras en Lista de Espera.')->warning()->send();
                            } else {
                                Notification::make()->title('La lista de espera está completa.')->danger()->send();
                            }
                        });
                    }),

                Tables\Actions\Action::make('aceptar_plaza')
                    ->label('¡Aceptar Plaza!')
                    ->button()->color('success')->icon('heroicon-m-check-badge')
                    ->visible(fn($record) => $record->bookings()->where('user_id', Auth::id())->where('status', 'waiting')->exists() && $record->bookings()->where('status', 'booked')->count() < $record->capacity)
                    ->action(function (GymSession $record) {
                        $user = Auth::user();
                        
                        // CORTAFUEGOS BACKEND: Por si se quedó sin clases mientras estaba en la lista de espera
                        if ($user->credits <= 0) {
                            Notification::make()->title('No puedes aceptar la plaza. No te quedan clases disponibles.')->danger()->send();
                            return;
                        }

                        $booking = $record->bookings()->where('user_id', $user->id)->where('status', 'waiting')->first();
                        if($booking) {
                            $booking->update(['status' => 'booked', 'notified_at' => null]);
                            $user->decrement('credits');
                            $this->dispatch('credits-updated');
                            Notification::make()->title('¡Plaza tuya!')->success()->send();
                        }
                    }),

                Tables\Actions\Action::make('desapuntarse')
                    ->label(fn($record) => $record->bookings()->where('user_id', Auth::id())->where('status', 'waiting')->exists() ? 'Salir de Espera' : 'Cancelar Reserva')
                    ->button()->color('danger')->requiresConfirmation()
                    ->visible(fn($record) => $record->bookings()->where('user_id', Auth::id())->exists())
                    ->action(function (GymSession $record) {
                        $booking = $record->bookings()->where('user_id', Auth::id())->first();
                        if (!$booking) return;

                        if ($booking->status === 'booked') {
                            Auth::user()->increment('credits');
                            $this->dispatch('credits-updated');
                        }
                        $booking->delete();
                        
                        $siguiente = $record->bookings()->where('status', 'waiting')->orderBy('created_at', 'asc')->first();
                        if ($siguiente) {
                            $siguiente->update(['notified_at' => now()]);
                            Notification::make()
                                ->title('¡Hueco libre en ' . $record->classType->name . '!')
                                ->body('Tienes EXACTAMENTE 5 MINUTOS para confirmar tu plaza.')
                                ->actions([ NotifyAction::make('aceptar')->label('Aceptar Plaza')->button()->color('success')->url("/confirmar-reserva/{$siguiente->id}") ])
                                ->sendToDatabase($siguiente->user);
                        }
                    }),
            ]);
    }
}

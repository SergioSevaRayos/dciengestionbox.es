<?php

namespace App\Filament\App\Pages;

use App\Filament\App\Widgets\PersonalRecordChart;
use App\Models\Exercise;
use App\Models\PersonalRecord;
use Filament\Pages\Page;
use Filament\Actions\Action;
use Filament\Actions\Contracts\HasActions;
use Filament\Forms\Contracts\HasForms;
use Filament\Actions\Concerns\InteractsWithActions;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DatePicker;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\Auth;

class MisMarcas extends Page implements HasActions, HasForms
{
    use InteractsWithActions;
    use InteractsWithForms;

    protected static ?string $navigationIcon = 'heroicon-o-trophy';
    protected static string $view = 'filament.app.pages.mis-marcas';
    protected static ?string $title = 'Mis Marcas Personales';

    public ?int $selectedExerciseId = null;

    // --- VISTA GENERAL (Tarjetas de progreso) ---
    public function getOverviewDataProperty()
    {
        $user = Auth::user();
        return collect(Exercise::all()->map(function ($exercise) use ($user) {
            $bestWeight = PersonalRecord::where('user_id', $user->id)
                ->where('exercise_id', $exercise->id)
                ->max('weight') ?? 0;

            // Limpieza robusta del Enum
            $nameStr = $exercise->name;
            if ($nameStr instanceof \UnitEnum) {
                $nameStr = $nameStr->value;
            } elseif (is_object($nameStr) && method_exists($nameStr, 'getLabel')) {
                $nameStr = $nameStr->getLabel();
            }

            // Extraemos el icono de forma segura
            $icon = 'heroicon-m-bolt'; // Icono por defecto
            if (is_object($exercise->name) && method_exists($exercise->name, 'getIcon')) {
                $icon = $exercise->name->getIcon() ?? $icon;
            }

            return (object) [
                'exercise' => clone $exercise, // Evitamos mutar la BD
                'exercise_id' => $exercise->id,
                'exercise_name' => (string) $nameStr,
                'icon_name' => $icon,
                'weight' => (float) $bestWeight,
                'max_weight' => (float) $bestWeight,
                'max' => $bestWeight > 0 ? (float)$bestWeight + 20 : 100,
            ];
        }))->filter(function ($item) {
            return $item->weight > 0;
        })->values();
    }

    // --- VISTA DETALLE (Historial al hacer clic) ---
    public function getRecordDataProperty(): array
    {
        if (!$this->selectedExerciseId) {
            return [
                'history' => collect(), 
                'max' => 100, 
                'name' => '', 
                'weight' => 0, 
                'max_weight' => 0,
                'icon_name' => 'heroicon-m-bolt',
                'exercise' => null
            ];
        }

        $user = Auth::user();
        $exercise = Exercise::find($this->selectedExerciseId);
        $history = PersonalRecord::where('user_id', $user->id)
            ->where('exercise_id', $this->selectedExerciseId)
            ->orderBy('achieved_at', 'desc')
            ->get();

        $bestWeight = $history->max('weight') ?? 0;
        
        // Limpieza robusta del Enum
        $nameStr = $exercise->name;
        if ($nameStr instanceof \UnitEnum) {
            $nameStr = $nameStr->value;
        } elseif (is_object($nameStr) && method_exists($nameStr, 'getLabel')) {
            $nameStr = $nameStr->getLabel();
        }

        // Extraemos el icono de forma segura
        $icon = 'heroicon-m-bolt'; // Icono por defecto
        if (is_object($exercise->name) && method_exists($exercise->name, 'getIcon')) {
            $icon = $exercise->name->getIcon() ?? $icon;
        }

        return [
            'exercise' => $exercise, // Pasamos el modelo completo por si acaso
            'name' => (string) $nameStr,
            'icon_name' => $icon,    // Y el icono ya resuelto en texto puro
            'max' => $bestWeight > 0 ? (float)$bestWeight : 100,
            'history' => $history,
            'weight' => (float)$bestWeight,
            'max_weight' => (float)$bestWeight,
        ];
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('nuevaMarca')
                ->label('Registrar Marca')
                ->icon('heroicon-m-plus')
                ->color('primary')
                ->form([
                    Select::make('exercise_id')
                        ->label('Ejercicio')
                        ->placeholder('Selecciona un ejercicio')
                        ->options(function() {
                            return collect(Exercise::all())->mapWithKeys(function ($exercise) {
                                $label = $exercise->name instanceof \UnitEnum 
                                    ? $exercise->name->value 
                                    : $exercise->name;
                                return [$exercise->id => $label];
                            });
                        })
                        ->default($this->selectedExerciseId)
                        ->required()
                        ->searchable(),
                    TextInput::make('weight')
                        ->label('Peso (kg)')
                        ->numeric()
                        ->required()
                        ->prefix('Kg'),
                    DatePicker::make('achieved_at')
                        ->label('Fecha')
                        ->default(now())
                        ->required(),
                ])
                ->action(function (array $data) {
                    PersonalRecord::create([
                        'user_id' => Auth::id(),
                        'exercise_id' => $data['exercise_id'],
                        'weight' => $data['weight'],
                        'achieved_at' => $data['achieved_at'],
                    ]);
                    Notification::make()->title('¡Récord guardado!')->success()->send();
                    $this->dispatch('record-updated');
                }),
        ];
    }

    protected function getHeaderWidgets(): array
    {
        return [
            PersonalRecordChart::class,
        ];
    }

    public function selectExercise($id)
    {
        $this->selectedExerciseId = $id;
        $this->dispatch('update-chart-filter', filter: $id);
    }
}

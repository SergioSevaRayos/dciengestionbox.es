<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;
use Filament\Facades\Filament;
use Filament\Actions\Action;
use Filament\Notifications\Notification;

class GymSubscription extends Page
{
    protected static ?string $navigationIcon = 'heroicon-o-credit-card';
    protected static ?string $navigationGroup = 'Configuración';
    protected static ?string $title = 'Suscripción y Pagos';
    protected static ?int $navigationSort = 100;
    protected static string $view = 'filament.pages.gym-subscription';

    public $tenant;

    public function mount()
    {
        $this->tenant = Filament::getTenant();
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('pay')
                ->label('Simular Pago (Stripe Local)')
                ->icon('heroicon-o-check-badge')
                ->color('success')
                ->visible(fn () => !$this->tenant->is_subscribed)
                ->requiresConfirmation()
                ->modalHeading('Simular pago de suscripción')
                ->modalDescription('Al confirmar, simularemos que el gimnasio ha pagado a través de Stripe y se desbloquearán todas las funciones.')
                ->action(function () {
                    $this->tenant->update(['is_subscribed' => true]);
                    
                    Notification::make()
                        ->title('¡Pago completado con éxito!')
                        ->body('Tu gimnasio ya tiene acceso total a la plataforma.')
                        ->success()
                        ->send();
                        
                    $this->redirect(static::getUrl());
                }),

            Action::make('cancel')
                ->label('Cancelar Suscripción (Pruebas)')
                ->icon('heroicon-o-x-circle')
                ->color('danger')
                ->visible(fn () => $this->tenant->is_subscribed)
                ->requiresConfirmation()
                ->action(function () {
                    $this->tenant->update(['is_subscribed' => false]);
                    $this->redirect(static::getUrl());
                }),
        ];
    }
}

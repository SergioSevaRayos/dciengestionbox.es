<?php

namespace App\Filament\Pages\Auth;

use Filament\Pages\Auth\Register as BaseRegister;
use Filament\Forms\Components\TextInput;
use App\Models\Gym;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class RegisterGymOwner extends BaseRegister
{
    protected function getForms(): array
    {
        return [
            'form' => $this->form(
                $this->makeForm()
                    ->schema([
                        $this->getNameFormComponent(),
                        $this->getEmailFormComponent(),
                        $this->getPasswordFormComponent(),
                        $this->getPasswordConfirmationFormComponent(),
                        
                        // ¡NUESTRO CAMPO ESTRELLA PARA EL SAAS!
                        TextInput::make('gym_name')
                            ->label('Nombre de tu Gimnasio')
                            ->required()
                            ->maxLength(255),
                    ])
                    ->statePath('data'),
            ),
        ];
    }

    protected function handleRegistration(array $data): Model
    {
        // 1. Dejamos que Filament cree el usuario normalmente (con su email y contraseña)
        $user = parent::handleRegistration($data);

        // 2. Creamos el nuevo gimnasio en la base de datos
        $gym = Gym::create([
            'name' => $data['gym_name'],
            // Creamos una URL amigable única (ej: crossfit-valencia-4829)
            'slug' => Str::slug($data['gym_name'] . '-' . rand(1000, 9999)), 
        ]);

        // 3. Vinculamos al nuevo usuario como dueño absoluto de este gimnasio
        $user->gyms()->attach($gym->id);

        // 4. Le ponemos el rol de gestor para que tenga todos los permisos
        $user->update(['role' => 'gestor']);

        return $user;
    }
}

<?php

namespace App\Filament\Resources\UserResource\Pages;

use App\Filament\Resources\UserResource;
use Filament\Resources\Pages\CreateRecord;
use App\Models\Package;
use Illuminate\Support\Facades\DB;

class CreateUser extends CreateRecord
{
    protected static string $resource = UserResource::class;

    protected function afterCreate(): void
    {
        $packageId = $this->data['assign_new_package'] ?? null;

        if ($packageId) {
            $package = Package::find($packageId);
            if ($package) {
                $user = $this->record;
                
                $nuevosCreditos = $user->credits + $package->credits;
                $user->update(['credits' => $nuevosCreditos]);

                // AQUÍ TAMBIÉN AÑADIMOS 'expires_at'
                DB::table('user_packages')->insert([
                    'user_id' => $user->id,
                    'package_id' => $package->id,
                    'remaining_credits' => $nuevosCreditos,
                    'expires_at' => now()->addDays($package->validity_days ?? 30),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
    }
}

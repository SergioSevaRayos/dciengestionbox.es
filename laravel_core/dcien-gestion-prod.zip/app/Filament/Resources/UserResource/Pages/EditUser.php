<?php

namespace App\Filament\Resources\UserResource\Pages;

use App\Filament\Resources\UserResource;
use Filament\Resources\Pages\EditRecord;
use App\Models\Package;
use Illuminate\Support\Facades\DB;

class EditUser extends EditRecord
{
    protected static string $resource = UserResource::class;

    protected function getHeaderActions(): array
    {
        return [
            \Filament\Actions\DeleteAction::make(),
        ];
    }

    protected function afterSave(): void
    {
        $packageId = $this->data['assign_new_package'] ?? null;

        if ($packageId) {
            $package = Package::find($packageId);
            if ($package) {
                $user = $this->record;
                $nuevosCreditos = $user->credits + $package->credits;
                
                $user->update(['credits' => $nuevosCreditos]);

                // AQUÍ AÑADIMOS 'expires_at' CALCULANDO LOS DÍAS DE VALIDEZ DEL BONO
                DB::table('user_packages')->insert([
                    'user_id' => $user->id,
                    'package_id' => $package->id,
                    'remaining_credits' => $nuevosCreditos,
                    'expires_at' => now()->addDays($package->validity_days ?? 30),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

                $this->data['credits'] = $nuevosCreditos;
                $this->data['assign_new_package'] = null;
            }
        }
    }
}

<?php

namespace App\Filament\Resources\PackageResource\Pages;

use App\Filament\Resources\PackageResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePackage extends CreateRecord
{
    protected static string $resource = PackageResource::class;

    // Te devuelvo a la lista al guardar para mejor experiencia
    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
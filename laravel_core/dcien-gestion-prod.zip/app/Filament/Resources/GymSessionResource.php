<?php
namespace App\Filament\Resources;

use App\Filament\Resources\GymSessionResource\Pages;
use App\Filament\Resources\GymSessionResource\RelationManagers;
use App\Models\GymSession;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class GymSessionResource extends Resource
{
    protected static ?string $model = GymSession::class;
    protected static ?string $modelLabel = 'Clase Programada';
    protected static ?string $pluralModelLabel = 'Calendario de Clases';
    protected static ?string $navigationLabel = 'Calendario';
    protected static ?string $navigationIcon = 'heroicon-o-calendar-days';
    protected static ?string $navigationGroup = 'Gestión Deportiva';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\Select::make('class_type_id')->relationship('classType', 'name')->required(),
            Forms\Components\DateTimePicker::make('start_time')->label('Inicio')->required(),
            Forms\Components\DateTimePicker::make('end_time')->label('Fin')->required(),
            Forms\Components\TextInput::make('capacity')->label('Aforo')->numeric()->default(20)->required(),
            Forms\Components\Section::make('Repetición Automática')->schema([
                Forms\Components\Toggle::make('is_recurring')->live(),
                Forms\Components\CheckboxList::make('days_of_week')
                    ->options([1=>'Lunes',2=>'Martes',3=>'Miércoles',4=>'Jueves',5=>'Viernes',6=>'Sábado',0=>'Domingo'])
                    ->visible(fn(Forms\Get $get) => $get('is_recurring')),
                Forms\Components\DatePicker::make('repeat_until')
                    ->visible(fn(Forms\Get $get) => $get('is_recurring')),
            ])->collapsed(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table->columns([
            Tables\Columns\TextColumn::make('classType.name')->label('Disciplina'),
            Tables\Columns\TextColumn::make('start_time')->label('Día y Hora')->dateTime('d/m/Y H:i'),
            
            // MAGIA: Columna que muestra la ocupación real
            Tables\Columns\TextColumn::make('ocupacion')
                ->label('Plazas Ocupadas')
                ->state(function (GymSession $record) {
                    $ocupadas = $record->bookings()->where('status', 'booked')->count();
                    return "{$ocupadas} / {$record->capacity}";
                })
                ->badge()
                ->color(function (GymSession $record) {
                    $ocupadas = $record->bookings()->where('status', 'booked')->count();
                    return $ocupadas >= $record->capacity ? 'danger' : 'success';
                }),
        ])->actions([
            Tables\Actions\EditAction::make()->label('Ver/Editar'),
            Tables\Actions\DeleteAction::make(),
        ]);
    }

    // CONECTAMOS EL GESTOR DE ALUMNOS AQUÍ
    public static function getRelations(): array
    {
        return [
            RelationManagers\BookingsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListGymSessions::route('/'),
            'create' => Pages\CreateGymSession::route('/create'),
            'edit' => Pages\EditGymSession::route('/{record}/edit'),
        ];
    }

    public static function canCreate(): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }
    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }


    


    public static function getNavigationLabel(): string
    {
        $label = parent::getNavigationLabel();
        $isSubscribed = \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
        if ($isSubscribed) {
            return $label;
        }
        return $isSubscribed ? $label : $label . " 🔒";
    }

}
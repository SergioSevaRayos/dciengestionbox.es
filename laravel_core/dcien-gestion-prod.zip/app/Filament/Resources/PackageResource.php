<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PackageResource\Pages;
use App\Models\Package;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class PackageResource extends Resource
{
    protected static ?string $model = Package::class;

    // --- CONFIGURACIÓN DEL MENÚ Y TRADUCCIONES ---
    protected static ?string $modelLabel = 'Bono o Tarifa';
    protected static ?string $pluralModelLabel = 'Bonos y Tarifas';
    protected static ?string $navigationLabel = 'Bonos y Tarifas';
    protected static ?string $navigationIcon = 'heroicon-o-ticket';
    protected static ?string $navigationGroup = 'Ventas y Facturación'; 
    protected static ?int $navigationSort = 3; 
    // ---------------------------------------------

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->label('Nombre del Bono')
                    ->placeholder('Ej: Bono 10 Clases, Tarifa Mensual...')
                    ->required()
                    ->maxLength(255),
                
                Forms\Components\TextInput::make('credits')
                    ->label('Número de Clases')
                    ->placeholder('Ej: 10')
                    ->numeric()
                    ->required(),
                
                Forms\Components\TextInput::make('price')
                    ->label('Precio (€)')
                    ->numeric()
                    ->prefix('€')
                    ->required(),
                
                Forms\Components\TextInput::make('validity_days')
                    ->label('Días de caducidad')
                    ->placeholder('Ej: 30. En blanco = Fin de mes.')
                    ->numeric(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('Nombre del Bono')
                    ->searchable(),
                
                Tables\Columns\TextColumn::make('credits')
                    ->label('Clases')
                    ->numeric()
                    ->sortable(),
                
                Tables\Columns\TextColumn::make('price')
                    ->label('Precio')
                    ->money('EUR')
                    ->sortable(),
                
                Tables\Columns\TextColumn::make('validity_days')
                    ->label('Caducidad')
                    ->formatStateUsing(fn (?string $state): string => $state ? $state . ' días' : 'Fin de mes'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPackages::route('/'),
            'create' => Pages\CreatePackage::route('/create'),
            'edit' => Pages\EditPackage::route('/{record}/edit'),
        ];
    }

    public static function canCreate(): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }
    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }
    public static function canDelete(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }


    


    public static function getNavigationLabel(): string
    {
        $label = parent::getNavigationLabel();
        $isSubscribed = \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
        if ($isSubscribed) {
            return $label;
        }
        return $isSubscribed ? $label : $label . " 🔒";
    }

}
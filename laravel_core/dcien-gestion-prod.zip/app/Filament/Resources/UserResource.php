<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Pages;
use App\Models\User;
use App\Models\Package;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Hash;

class UserResource extends Resource
{
    protected static ?string $model = User::class;
    protected static bool $isScopedToTenant = true;
    protected static ?string $tenantOwnershipRelationshipName = 'gyms';
    protected static ?string $navigationIcon = 'heroicon-o-users';
    protected static ?string $navigationGroup = 'Gestión De Usuarios';
    protected static ?string $modelLabel = 'Alumno / Usuario';
    protected static ?string $pluralModelLabel = 'Gestión De Usuarios';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Datos del Usuario')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('Nombre completo')
                            ->required(),
                            
                        Forms\Components\TextInput::make('email')
                            ->label('Correo Electrónico')
                            ->email()
                            ->required()
                            ->unique(ignoreRecord: true),
                            
                        Forms\Components\Select::make('role')
                            ->label('Rol')
                            ->options([
                                'student' => 'Alumno',
                                'admin' => 'Administrador',
                            ])
                            ->required()
                            ->default('student'),
                            
                        Forms\Components\TextInput::make('password')
                            ->label('Contraseña (Opcional)')
                            ->password()
                            ->dehydrateStateUsing(fn ($state) => Hash::make($state))
                            ->dehydrated(fn ($state) => filled($state))
                            ->required(fn (string $context): bool => $context === 'create')
                            ->helperText('Déjalo en blanco si vas a generarle un enlace de acceso.'),
                    ])->columns(2),

                Forms\Components\Section::make('Gestión de Bonos y Clases')
                    ->description('Asigna bonos oficiales para que el alumno reciba los créditos y empiecen a contar sus días de acceso.')
                    ->schema([
                        Forms\Components\TextInput::make('credits')
                            ->label('Clases Disponibles (Actuales)')
                            ->numeric()
                            ->default(0)
                            ->required()
                            ->helperText('Muestra las clases que tiene ahora mismo. Puedes corregirlas manualmente.'),
                        
                        Forms\Components\Select::make('assign_new_package')
                            ->label('Añadir Nuevo Bono')
                            ->options(Package::pluck('name', 'id'))
                            ->placeholder('Selecciona un bono...')
                            ->dehydrated(false) // No lo guarda como columna de usuario
                            ->helperText('Selecciona un bono. Al darle a guardar, se sumarán sus clases automáticamente.'),
                    ])->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')->label('Nombre')->searchable(),
                Tables\Columns\TextColumn::make('email')->label('Email')->searchable(),
                Tables\Columns\TextColumn::make('role')
                    ->label('Rol')
                    ->badge()
                    ->colors([
                        'primary' => 'admin',
                        'success' => 'student',
                    ]),
                Tables\Columns\TextColumn::make('credits')->label('Clases Disp.')->sortable(),
                Tables\Columns\TextColumn::make('created_at')->label('Registro')->dateTime('d/m/Y')->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
        ];
    }

    public static function canCreate(): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }
    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }


    


    public static function getNavigationLabel(): string
    {
        $label = parent::getNavigationLabel();
        $isSubscribed = \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
        if ($isSubscribed) {
            return $label;
        }
        return $isSubscribed ? $label : $label . " 🔒";
    }

}
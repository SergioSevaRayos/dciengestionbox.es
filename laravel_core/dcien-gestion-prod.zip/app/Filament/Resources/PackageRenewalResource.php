<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PackageRenewalResource\Pages;
use App\Models\PackageRenewal;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Collection;
use Filament\Notifications\Notification;
use Illuminate\Support\Facades\DB;

class PackageRenewalResource extends Resource
{
    protected static ?string $model = PackageRenewal::class;
    protected static ?string $navigationIcon = 'heroicon-o-banknotes';
    protected static ?string $navigationGroup = 'Ventas y Facturación';
    protected static ?string $modelLabel = 'Solicitud de Renovación';
    protected static ?string $pluralModelLabel = 'Renovaciones Pendientes';
    protected static ?int $navigationSort = 3;

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('user.name')->label('Alumno')->searchable(),
                Tables\Columns\TextColumn::make('package.name')->label('Bono Solicitado'),
                Tables\Columns\TextColumn::make('package.price')->label('Precio')->money('EUR'),
                Tables\Columns\BadgeColumn::make('status')
                    ->label('Estado')
                    ->colors([
                        'warning' => 'pendiente',
                        'success' => 'aprobado',
                        'danger' => 'rechazado',
                    ]),
                Tables\Columns\TextColumn::make('created_at')->label('Fecha Solicitud')->dateTime()->sortable(),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options(['pendiente' => 'Pendientes', 'aprobado' => 'Aprobadas', 'rechazado' => 'Rechazadas'])
                    ->default('pendiente'),
            ])
            ->bulkActions([
                Tables\Actions\BulkAction::make('aprobar_masivo')
                    // CAMBIO 1: Modificado el texto del botón y el icono para reflejar que solo se activa el bono
                    ->label('Activar Bonos Seleccionados')
                    ->icon('heroicon-o-bolt')
                    ->color('primary')
                    ->requiresConfirmation()
                    ->modalHeading('Activar renovaciones')
                    ->modalDescription('¿Confirmas que deseas activar estos bonos? Se les sumarán los créditos automáticamente a los alumnos, pero los pagos quedarán marcados como PENDIENTES hasta que los confirmes en la pestaña de Morosos.')
                    ->modalSubmitActionLabel('Sí, Activar Bonos')
                    ->action(function (Collection $records) {
                        $count = 0;
                        foreach ($records as $record) {
                            if ($record->status === 'pendiente') {
                                $user = $record->user;
                                $package = $record->package;

                                $record->update(['status' => 'aprobado']);
                                
                                $nuevosCreditos = $user->credits + $package->credits;
                                $user->update(['credits' => $nuevosCreditos]);

                                // CAMBIO 2: Nos aseguramos de inyectar 'is_paid' => false explícitamente por seguridad
                                DB::table('user_packages')->insert([
                                    'user_id' => $user->id,
                                    'package_id' => $package->id,
                                    'is_paid' => false, // IMPORTANTE: Se va a la lista de morosos
                                    'remaining_credits' => $nuevosCreditos,
                                    'expires_at' => now()->addDays($package->validity_days ?? 30),
                                    'created_at' => now(),
                                    'updated_at' => now(),
                                ]);
                                
                                $count++;
                            }
                        }
                        Notification::make()
                            ->title("$count bonos activados correctamente")
                            ->body('Recuerda confirmar los pagos en la pestaña de Pendientes de Pago.')
                            ->success()
                            ->send();
                    }),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPackageRenewals::route('/'),
        ];
    }
    
    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::where('status', 'pendiente')->count() ?: null;
    }

    public static function canCreate(): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }
    public static function canEdit(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }
    public static function canDelete(\Illuminate\Database\Eloquent\Model $record): bool
    {
        return \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
    }


    


    public static function getNavigationLabel(): string
    {
        $label = parent::getNavigationLabel();
        $isSubscribed = \Filament\Facades\Filament::getTenant()?->is_subscribed ?? false;
        if ($isSubscribed) {
            return $label;
        }
        return $isSubscribed ? $label : $label . " 🔒";
    }

}
<x-filament-widgets::widget>
    {{-- El wire:poll.3s es la magia asíncrona que refresca los datos cada 3 segundos automáticamente --}}
    <x-filament::section wire:poll.3s="loadData">
        <div class="flex flex-col sm:flex-row items-center justify-between gap-4">
            
            <div class="flex flex-wrap items-center gap-4 sm:gap-8">
                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Bono Actual</p>
                    <h2 class="text-xl font-bold dark:text-white">{{ $currentPackageName }}</h2>
                </div>

                <div class="hidden sm:block h-10 w-px bg-gray-200 dark:bg-gray-700"></div>

                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Clases Disponibles</p>
                    <h2 class="text-xl font-bold {{ $creditsLeft <= 2 ? 'text-danger-500' : 'text-primary-500' }}">
                        {{ $creditsLeft }}
                    </h2>
                </div>

                <div class="hidden sm:block h-10 w-px bg-gray-200 dark:bg-gray-700"></div>

                <div>
                    <p class="text-sm font-medium text-gray-500 dark:text-gray-400">Caducidad</p>
                    <h2 class="text-xl font-bold dark:text-white">
                        @if($daysLeft > 0 && $daysLeft != 999)
                            <span class="{{ $daysLeft <= 3 ? 'text-danger-500' : 'text-success-500' }}">{{ $daysLeft }} días</span>
                        @elseif($daysLeft === 0 && $currentPackageName !== 'Ninguno')
                            <span class="text-danger-500">Caduca hoy</span>
                        @elseif($daysLeft < 0)
                            <span class="text-danger-500">Caducado</span>
                        @else
                            <span class="text-gray-500">-</span>
                        @endif
                    </h2>
                </div>
            </div>

            <div class="flex items-center mt-4 sm:mt-0 transition-all duration-300">
                @if($hasPending)
                    <span class="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-full text-xs font-medium bg-warning-50 text-warning-600 border border-warning-200 dark:bg-warning-500/10 dark:border-warning-500/20">
                        <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                        Gestor validando pago...
                    </span>
                @elseif($daysLeft <= 3 || $daysLeft == 999 || $creditsLeft <= 2)
                    {{ $this->renewAction }}
                @endif
            </div>
        </div>
    </x-filament::section>

    <x-filament-actions::modals />
</x-filament-widgets::widget>

<?php

use Illuminate\Support\Facades\Route;

// Redirigir la entrada principal de la web al login unificado
Route::get('/', function () {
    return redirect('/admin/login');
});
